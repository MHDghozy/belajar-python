# import mymodule as mm

# mm.area_of_square(10)
# mm.area_of_square(35)

# mm.area_of_triangle(10, 5)

from mymodule import area of square

area_of_square(10)
area_of_square(35)